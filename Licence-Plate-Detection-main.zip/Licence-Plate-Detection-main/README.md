Upload any mp4 video related to vehicle and it detect and give output video (number plate detected in this video )
